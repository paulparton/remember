define(function(require, exports, module) {

    var game = require('game');
    var gameBoard = document.querySelector('#gameBoard');

    game.init(gameBoard);

});
