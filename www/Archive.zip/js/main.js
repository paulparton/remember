require(["modules/test"], function(test) {

  console.log('requireTest', test);

});
